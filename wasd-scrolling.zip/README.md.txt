Hey, quick add-on to allow for scrolling with W,A,S,D. 

There's also Q and E, Q to decrease scroll speed and E to increase it.